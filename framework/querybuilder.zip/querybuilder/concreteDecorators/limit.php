<?php
class limit extends aggregation{
    public function __construct(operation $operation,$parameters)
    {
        if($operation->function=="select"){
            parent:: __construct($operation);
            $this->parameters=$parameters;// it will receive a number which  will defines how many records this query will return
        }
        else 
        {
            echo "";
            exit();

        }
        
    }
    public function concatenate(): string
    {

        $this->currentStringQuery=" limit ".$this->parameters;
        return $this->operation->concatenate()." ".$this->currentStringQuery;
    }
    // public function run(){

    // }
    
}

?>