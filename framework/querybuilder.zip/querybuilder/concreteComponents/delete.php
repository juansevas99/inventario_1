<?php

class delete extends operation {
    function __construct()
    {
        parent::__construct();
    }

    public function concatenate(): string
    {
       return parent::concatenate();
    }
    public function run(){

    }
    
}

?>